package com.example.shared;

public class MyClass {
}
